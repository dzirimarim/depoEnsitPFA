export class Role {
    id ?: number
    roleName ?:string
    priority ?: number
}
