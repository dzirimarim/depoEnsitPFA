export class Category {
   
    constructor( private id:string,
                 public title:string){

                 }
}