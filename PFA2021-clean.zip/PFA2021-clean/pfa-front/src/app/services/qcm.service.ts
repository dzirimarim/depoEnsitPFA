import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class QcmService {
  getAll() {
    throw new Error('Method not implemented.');
  }

  constructor() { }
}
