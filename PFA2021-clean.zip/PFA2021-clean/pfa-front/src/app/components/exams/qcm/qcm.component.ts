import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qcm',
  templateUrl: './qcm.component.html',
  styleUrls: ['./qcm.component.css']
})
export class QcmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
