import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-programming-test',
  templateUrl: './edit-programming-test.component.html',
  styleUrls: ['./edit-programming-test.component.scss']
})
export class EditProgrammingTestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
