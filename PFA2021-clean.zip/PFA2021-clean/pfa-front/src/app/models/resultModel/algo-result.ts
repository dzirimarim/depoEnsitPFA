export class AlgoResult {
}
