export class QcmResult {
}
