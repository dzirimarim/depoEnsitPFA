export class RegisterModel {
    name : string = "";
    username : string = "";
    address : string = "";
    password : string = "";
    email : string = "";

}
