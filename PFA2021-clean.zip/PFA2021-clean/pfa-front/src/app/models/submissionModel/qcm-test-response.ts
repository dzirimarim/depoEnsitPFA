export class QcmTestResponse {

    testId:Number=-1;
    responseId:Number=-1;
    userId : Number =-1;
    

}
