export class AlgoSubmission {
    problemId : Number = -1;
    userId : Number =-1;
    teamId : number =-1;
    language : String = "";
    solution ?: File;
}
