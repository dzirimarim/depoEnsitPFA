export class PropositionReponse {
propositionId :String='';
isTrue:boolean=false;
}