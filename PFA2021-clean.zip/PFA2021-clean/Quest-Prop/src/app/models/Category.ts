export class Category {
   
    constructor( private id:string,
                 private title:string){

                 }
}